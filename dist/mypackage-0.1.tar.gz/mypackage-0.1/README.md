# mypackage
This program is created as an example of how to publish your own python package.

Welcome
This package is a test package for sorting an array or list of item in descending order
